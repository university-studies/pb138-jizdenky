package ZastavkyXmlCreator;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import javax.xml.transform.OutputKeys;
 
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * @author Mejzlik Ondrej 406825
 * @version 19.4.2014
 */
public class ZastavkyXmlCreator {
    
    //Jmena pouzitych souboru -------------------------------
    public static final String INPUT_FILE = "zastavky9.txt";
    public static final String OUTPUT_FILE = "zastavky.xml";
    //-------------------------------------------------------
    
    private Document doc = null;
    
    /**
     * Konstruktor pro objekty tridy ZastavkyXmlCreator. 
     * Vytvori novy xml soubor a ulozi ho do promene tridy doc.
     */
    ZastavkyXmlCreator()
    {
        try
        {    
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            doc = builder.newDocument();
        }
        catch (FactoryConfigurationError ex)
        {
            ex.printStackTrace();
        }
        catch (ParserConfigurationException ex)
        {
            ex.printStackTrace();
        }
    }

    /**
     * Vytvori xml dokument a ulozi do nej zeleznicni stanice.
     * 
     * @param args Argumenty prikazove radky
     */
    public static void main(String[] args) 
    {
        ZastavkyXmlCreator creator = new ZastavkyXmlCreator();
        
        try
        {
            creator.createTrainStops(INPUT_FILE);
            creator.witeXMLFile(OUTPUT_FILE);
        }
        catch(FileNotFoundException ex)
        {
            System.out.println("No input file.");
        }   
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }
    }
    /**
     * Cte ze souboru zastavky a uklada je do dokumentu XML, ktery si vytvori. 
     * Dokument ma strukturu, korenovy element train_stations, pod kterym je seznam
     * zastavek uzavrenych v elementech station s adtributem s_id - id zastavky, zone - zona zastavky.
     * 
     * @param fileName Jmeno souboru, ze ktereho se ctou zastavky. Format radku - 1:225 Adamov III (id:zona <mezera> nazev)
     * @throws FileNotFoundException Pokud soubor nelze otevrit.
     * @throws IOException V pripade chyby pri cteni.
     */
    public void createTrainStops(String fileName) throws FileNotFoundException, IOException
    {
        BufferedReader reader = new BufferedReader(new FileReader(new File(fileName)));     
        String line;
        
        //Vytvoreni root elementu seznamu stanic
        Element trainStations = doc.createElement("train_stations");
        doc.appendChild(trainStations);
        
        try
        {
            while((line = reader.readLine()) != null)
            {
                String idAndRest[] = line.split(":", 2);
                if(idAndRest.length != 2)
                {
                    throw new IOException("Wrong input file format ID and the rest");
                }
            
                String zoneAndName[] = idAndRest[1].split(" ", 2);
                if(zoneAndName.length != 2)
                {
                    throw new IOException("Wrong input file format Zone and name");
                }
            
                Element station = doc.createElement("station");
                station.appendChild(doc.createTextNode(zoneAndName[1]));
		trainStations.appendChild(station);
                
		station.setAttribute("s_id", idAndRest[0]);
                station.setAttribute("zone", zoneAndName[0]);
            }
        }
        finally
        {
            reader.close();
        }
    }
    
    /**
     * Zapise XML soubor se zastavkami na disk vcetne formatovani na radky.
     * 
     * @param name Jmeno souboru k zapsani vcetne pripony xml.
     */
    public void witeXMLFile(String name)
    {
        try
        {
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            transformerFactory.setAttribute("indent-number", 4); 
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");  
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(name));

            transformer.transform(source, result);   
            System.out.println("Done");
            System.out.println("Written file: "+name);
        }
        catch (TransformerException ex) 
        {
            ex.printStackTrace();
	}
    }
    
}
